"""Executable synthetic conformance suite. No primary source scientific validation."""
import copy, json,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from validate_par import CORE, RELEASE, validate, structural_errors
from jsonschema import Draft202012Validator

def fixture(name): return json.loads((ROOT/'fixtures'/f'{name}.json').read_text())

class CandidateTests(unittest.TestCase):
 def assertValid(self,r,release=False):
  self.assertEqual([],validate(r,release),f'unexpected error: {validate(r,release)}')
 def assertInvalid(self,r,release=False):
  self.assertTrue(validate(r,release),f'expected rejection {r}')
 def test_01_core_schema(self): Draft202012Validator.check_schema(CORE)
 def test_02_release_schema(self): Draft202012Validator.check_schema(RELEASE)
 def test_03_quant_primary_noncurie(self): self.assertValid(fixture('physical_measurement'),True)
 def test_04_relational_draft_no_evidence(self): self.assertValid(fixture('relational_unevidenced_draft'))
 def test_05_draft_not_released(self): self.assertInvalid(fixture('relational_unevidenced_draft'),True)
 def test_06_process(self): self.assertValid(fixture('process'),True)
 def test_07_conjecture(self): self.assertValid(fixture('conjecture_draft'))
 def test_08_contradictory_but_traced_release(self): self.assertValid(fixture('contradictory_released'),True)
 def test_09_measured_zero(self): self.assertValid(fixture('measured_zero'),True)
 def test_10_null_result(self): self.assertValid(fixture('null_result'),True)
 def test_11_failure_record(self): self.assertValid(fixture('failed_observation_draft'))
 def test_12_composition_new_evidence(self): self.assertValid(fixture('composed_with_own_evidence'),True)
 def test_13_projection_with_basis(self): self.assertValid(fixture('scope_projection_draft'))
 def test_14_multiple_distributions_single_origin(self): self.assertValid(fixture('two_distributions_single_origin'),True)
 def test_15_not_derivable(self): self.assertValid(fixture('not_derivable_draft'))
 def test_16_released_without_evidence_rejected(self):
  r=fixture('physical_measurement');r['evidence']=[];self.assertInvalid(r,True)
 def test_17_missing_evidence_locator_rejected(self):
  r=fixture('physical_measurement');del r['evidence'][0]['source']['locator'];self.assertInvalid(r,True)
 def test_18_missing_evidence_id_rejected(self):
  r=fixture('physical_measurement');del r['evidence'][0]['evidence_id'];self.assertInvalid(r,True)
 def test_19_negative_uncertainty_rejected(self):
  r=fixture('physical_measurement');r['proposition']['result']['uncertainty']['value']=-0.1;self.assertInvalid(r)
 def test_20_missing_quant_unit_rejected(self):
  r=fixture('physical_measurement');del r['proposition']['result']['unit'];self.assertInvalid(r)
 def test_21_invalid_interval_bounds_rejected(self):
  r=fixture('physical_measurement');r['proposition']['result']['uncertainty']={'kind':'confidence_interval','lower':5,'upper':3,'level':0.95};self.assertInvalid(r)
 def test_22_measured_zero_vs_null_state(self):
  r=fixture('measured_zero');self.assertEqual(r['proposition']['result']['value'],0)
  n=fixture('null_result');self.assertNotIn('value',n['proposition']['result'])
  self.assertNotEqual(r['evidence'][0]['outcome'],n['evidence'][0]['outcome'])
 def test_23_unjustified_scope_projection_rejected(self):
  r=fixture('scope_projection_draft');del r['scope']['projection']['basis'];self.assertInvalid(r)
 def test_24_unmarked_scope_drift_rejected(self):
  r=fixture('physical_measurement');r['scope']['claimed_system']={'scheme':'local','value':'different'};self.assertInvalid(r)
 def test_25_composition_inherits_evidence_rejected(self):
  r=fixture('composed_with_own_evidence');r['derivation']['inherited_evidence']=True;self.assertInvalid(r)
 def test_26_composition_missing_inputs_rejected(self):
  r=fixture('composed_with_own_evidence');r['derivation']['components']=[];self.assertInvalid(r)
 def test_27_composition_missing_rule_rejected(self):
  r=fixture('composed_with_own_evidence');del r['derivation']['rule'];self.assertInvalid(r)
 def test_28_process_bad_endpoint_rejected(self):
  r=fixture('process');r['proposition']['transitions'][0]['to']='missing-step';self.assertInvalid(r)
 def test_29_duplicate_step_ids_rejected(self):
  r=fixture('process');r['proposition']['steps'][1]['step_id']='step-a';self.assertInvalid(r)
 def test_30_duplicate_evidence_id_rejected(self):
  r=fixture('physical_measurement');r['evidence'].append(copy.deepcopy(r['evidence'][0]));self.assertInvalid(r)
 def test_31_revision_without_predecessor_rejected(self):
  r=fixture('physical_measurement');r['record_identity']['revision_kind']='scientific_revision';self.assertInvalid(r)
 def test_32_initial_with_predecessor_rejected(self):
  r=fixture('physical_measurement');r['record_identity']['predecessors']=[{'par_id':'other','par_version':'1'}];self.assertInvalid(r)
 def test_33_missing_status_rejected(self):
  r=fixture('physical_measurement');del r['record_status'];self.assertInvalid(r)
 def test_34_reported_context_without_value_rejected(self):
  r=fixture('physical_measurement');r['scope']['context'][0]['state']='reported';self.assertInvalid(r)
 def test_35_unknown_context_value_rejected(self):
  r=fixture('physical_measurement');r['scope']['context'][0]['value']=0;self.assertInvalid(r)
 def test_36_explicit_empty_array_as_reported_context(self):
  r=fixture('physical_measurement');r['scope']['context'][0].update({'state':'reported','value':[]});self.assertValid(r)
 def test_37_context_null_rejected_as_reported(self):
  r=fixture('physical_measurement');r['scope']['context'][0].update({'state':'reported','value':None});self.assertInvalid(r)
 def test_38_failed_vs_missing_are_distinct(self):
  r=fixture('failed_observation_draft');self.assertEqual('failed',r['evidence'][0]['outcome'])
  self.assertNotEqual('unreported',r['evidence'][0]['outcome']);self.assertValid(r)
 def test_39_released_without_rights_open_is_structural_only(self):
  r=fixture('physical_measurement');self.assertEqual('unknown',r['rights']['access']);self.assertValid(r,True)
 def test_40_lossless_json_roundtrip(self):
  r=fixture('process');self.assertEqual(r,json.loads(json.dumps(r)))
if __name__=='__main__':unittest.main()
