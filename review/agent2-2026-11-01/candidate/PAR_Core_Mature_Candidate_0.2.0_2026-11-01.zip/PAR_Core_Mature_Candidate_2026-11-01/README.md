# PAR Core mature scientific candidate 0.2.0

Status: Agent 1 independent construction candidate. No scientific acceptance, public specification release, biological source verification or Agent 2 implementation review.

## Contents

- `docs/CORE_SCIENTIFIC_CANDIDATE.md` scientific candidate definitions and unresolved questions
- `docs/COMPARISON_V0_01.md` verified differences against GitHub v0.01
- `docs/AGENT_2_CHALLENGE.md` independent review questions
- `schemas/par-core.schema.json` candidate typed proposition structure
- `schemas/par-release.schema.json` supplemental release evidence presence gate
- `tools/build_schema.py` reproducible schema generation
- `tools/validate_par.py` structural and internal semantic validation
- `tools/make_fixtures.py` fictional test fixture generation
- `fixtures/` twelve synthetic examples
- `tests/test_candidate.py` 40 conformance and negative controls
- `reports/` machine output, manifest and reproducibility description

## Run

Requires Python 3 and `jsonschema==4.26.0` or compatible 4.x:

```sh
python tools/build_schema.py
python tools/make_fixtures.py
python -m unittest discover -s tests -v
python tools/validate_par.py fixtures/physical_measurement.json --release
python tools/validate_par.py fixtures/relational_unevidenced_draft.json
```

JSON schema and semantic validation passes measure syntax and selected consistency only. A source fidelity check and release authorization require additional evidence.
