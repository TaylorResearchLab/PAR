#!/usr/bin/env python3
"""Generate fictional, explicitly synthetic examples for candidate conformance tests."""
import copy,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def ident(scheme,value,label=None):
 x={'scheme':scheme,'value':value}
 if label: x['label']=label
 return x

def source(kind,identifier,locator):
 return {'kind':kind,'identifier':identifier,'locator':locator}

ORIGIN=source('instrument_record',ident('laboratory-local','instrument-run-17'),'run-17/trace-A/measurement-1')
ISSUER=ident('laboratory-local','issuer-team-1')
SYSTEM=ident('local','test-apparatus-4')
CLAIM=ident('local','apparatus-rate')
EVIDENCE={'evidence_id':'ev-physical-001','source':ORIGIN,'basis':'experimental_measurement','direction':'supports',
 'outcome':'positive','independence':'unknown','modality':'time-resolved measurement'}

def quant():
 return {'type':'quantitative','quantity':ident('local','decay-rate'),
   'result':{'state':'observed','value':4.12,'unit':ident('unit','s^-1'),
             'uncertainty':{'kind':'standard_error','value':0.15}},
   'estimand':'mean rate in apparatus 4','parameter':ident('local','model-parameter-k')}

def base():
 return {'schema_version':'0.2.0-candidate',
   'par_id':'urn:uuid:18efcf8a-53b7-454d-9ecb-2c663b9fa15b','par_version':'1',
   'record_status':'released',
   'record_identity':{'revision_kind':'initial','predecessors':[],
                      'origin_assertion_identifier':ident('laboratory-local','original-observation-17')},
   'proposition':quant(),
   'interpretation':{'polarity':'affirmative','epistemic_status':'observed','conflict_status':'none_known'},
   'scope':{'observed_system':SYSTEM,'claimed_system':SYSTEM,'unit_of_observation':'one instrument run',
            'aggregation_level':'single','projection':{'kind':'none'},'context':[
                 {'field':ident('lab-field','temperature'),'state':'not_reported'}]},
   'evidence':[copy.deepcopy(EVIDENCE)],
   'provenance':{'original_issuer':ISSUER,'origin':ORIGIN,'activities':[], 'distribution':[]},
   'derivation':{'kind':'primary','components':[]},
   'verification':{'status':'unverified','reviewers':[]},
   'rights':{'access':'unknown','statement':'Fictional test material: no licensing evidence','source':ORIGIN},
   'profiles':[]}

def make():
 records={}
 records['physical_measurement']=base()
 r=base();r['par_id']='urn:uuid:5f5a2168-53b1-45e0-8135-688f904b3f47';r['record_status']='draft';r['evidence']=[]
 r['proposition']={'type':'relational','subject':ident('custom','specimen-4'), 'predicate':ident('local','reacts-with'), 'object':ident('custom','reagent-6')}
 r['interpretation']['epistemic_status']='asserted'
 records['relational_unevidenced_draft']=r
 r=base();r['par_id']='urn:uuid:a26697a9-e369-450c-802e-b0a75f753a9a'
 r['proposition']={'type':'process','process_name':'Fictional two-step sequence',
    'steps':[{'step_id':'step-a','action':'apply input'},{'step_id':'step-b','action':'measure outcome'}],
    'transitions':[{'from':'step-a','to':'step-b','relation':'precedes'}]}
 r['evidence'][0]['basis']='direct_observation'
 records['process']=r
 r=copy.deepcopy(records['relational_unevidenced_draft']);r['par_id']='urn:uuid:a81f0fee-5dfb-476d-8902-111ee4991b5e'
 r['proposition']={'type':'conjecture','hypothesis':{'type':'process','process_name':'Hypothesized mechanism',
  'steps':[{'step_id':'a','action':'initiation'},{'step_id':'b','action':'response'}],
  'transitions':[{'from':'a','to':'b','relation':'causal_model'}]},
  'rationale':'Fictional rationale; no experimental validation',
  'predictions':[{'statement':'A response is predicted under an indicated intervention'}]}
 r['interpretation']['epistemic_status']='hypothesized'
 records['conjecture_draft']=r
 r=copy.deepcopy(records['relational_unevidenced_draft']);r['par_id']='urn:uuid:ee828a7c-b2f4-44eb-aeae-81512d976321'
 r['record_status']='released';r['evidence']=[copy.deepcopy(EVIDENCE)];r['evidence'][0]['direction']='contradicts';r['evidence'][0]['outcome']='negative'
 r['interpretation']['epistemic_status']='disputed';r['interpretation']['conflict_status']='reported_conflict'
 records['contradictory_released']=r
 r=base();r['par_id']='urn:uuid:5f192838-9dd1-43f7-aee1-d07133a425ca';r['proposition']['result']['value']=0.0
 r['proposition']['result']['uncertainty']={'kind':'exact'};r['evidence'][0]['outcome']='measured_zero';records['measured_zero']=r
 r=base();r['par_id']='urn:uuid:1c626a9e-2f3e-44f9-bcc8-9d002d19ba2c';r['proposition']['result']={'state':'not_observed'}
 r['evidence'][0]['outcome']='null_result';r['evidence'][0]['direction']='inconclusive';records['null_result']=r
 r=base();r['par_id']='urn:uuid:34f92b84-0628-4f60-bb98-b57cd86d37b0';r['record_status']='draft'
 r['proposition']['result']={'state':'not_observed'};r['evidence'][0]['outcome']='failed';r['evidence'][0]['direction']='inconclusive'
 records['failed_observation_draft']=r
 r=base();r['par_id']='urn:uuid:1d22baee-c8d2-4395-98f8-70bb5400d387'
 r['derivation']={'kind':'composition','components':[{'par_id':'urn:uuid:b7e71fc1-c59e-4b24-a9fe-ab2cda944c4a','par_version':'1'}],
   'rule':'Fictional rule, inputs alone are not transferred evidence','inherited_evidence':False,
   'activity_id':'analysis-7'}
 r['evidence'][0]={'evidence_id':'ev-new-analysis','source':source('analysis_artifact',ident('analysis','analysis-7'),'analysis-7/output/1'),
    'basis':'computational_inference','direction':'supports','outcome':'positive','independence':'unknown'}
 records['composed_with_own_evidence']=r
 r=base();r['par_id']='urn:uuid:7258f4d9-b891-4b9d-893f-a42312e5400f';r['record_status']='draft';r['evidence']=[]
 r['scope']['claimed_system']=ident('local','different-apparatus');r['scope']['projection']={'kind':'inference','basis':'Fictional calibration mapping'}
 records['scope_projection_draft']=r
 r=base();r['par_id']='urn:uuid:c32f381c-0c10-4e18-9b6a-bc1ba947c113'
 r['provenance']['distribution']=[{'distributor':ident('institution','mirrorA'),'distribution_record':source('dataset_record',ident('URI','https://example.org/distribution/a'),'records/item1')},
  {'distributor':ident('institution','mirrorB'),'distribution_record':source('dataset_record',ident('URI','https://example.org/distribution/b'),'records/item2')}]
 records['two_distributions_single_origin']=r
 r=base();r['par_id']='urn:uuid:666e6cce-fcdf-4db4-93ae-dc5e7191e167';r['evidence'][0]['outcome']='not_derivable';r['evidence'][0]['direction']='inconclusive'
 r['proposition']['result']={'state':'not_observed'};r['record_status']='draft';r['interpretation']['epistemic_status']='undetermined'
 records['not_derivable_draft']=r
 for k,r in records.items():
  p=ROOT/'fixtures'/f'{k}.json';p.write_text(json.dumps(r,indent=2)+'\n')
 print('Wrote',len(records),'fictional fixtures')
if __name__=='__main__':make()
