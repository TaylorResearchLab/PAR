#!/usr/bin/env python3
"""Build a deliberately provisional PAR Core JSON Schema (Draft 2020-12).

Scientific decisions remain subject to independent review and user acceptance.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def obj(properties, required=(), *, additional=False, **kwargs):
    return {'type':'object','properties':properties,'required':list(required),'additionalProperties':additional,**kwargs}

def s(minlength=1): return {'type':'string','minLength':minlength}
def arr(items, minitems=0): return {'type':'array','items':items,'minItems':minitems}
def e(*x): return {'type':'string','enum':list(x)}
def ref(x): return {'$ref':f'#/$defs/{x}'}
def num(): return {'type':'number'}

ident = obj({'scheme':s(),'value':s(),'label':s(1)},['scheme','value'])
parref = obj({'par_id':s(),'par_version':s()},['par_id','par_version'])
source = obj({'kind':e('publication','dataset_record','instrument_record','activity_record','analysis_artifact','formal_derivation','other'),
              'identifier':ident,'locator':s(),'version':s(),'retrieved_at':{'type':'string','format':'date-time'}},['kind','identifier','locator'])
uncertainty=obj({'kind':e('standard_error','standard_deviation','confidence_interval','credible_interval','distribution','not_reported','exact','other'),
                 'value':num(),'lower':num(),'upper':num(),'level':{'type':'number','exclusiveMinimum':0,'exclusiveMaximum':1},
                 'distribution':s(),'parameters':{'type':'object','additionalProperties':{'type':['number','string','boolean']}}},['kind'])
uncertainty['allOf']=[
 {'if':{'properties':{'kind':{'enum':['standard_error','standard_deviation']}}},'then':{'required':['value']}},
 {'if':{'properties':{'kind':{'enum':['confidence_interval','credible_interval']}}},'then':{'required':['lower','upper','level']}},
 {'if':{'properties':{'kind':{'const':'distribution'}}},'then':{'required':['distribution']}},
 {'if':{'properties':{'kind':{'enum':['not_reported','exact']}}},'then':{'not':{'anyOf':[{'required':['value']},{'required':['lower']},{'required':['distribution']}]}}}
]
rel=obj({'type':{'const':'relational'},'subject':ident,'predicate':ident,'object':ident},['type','subject','predicate','object'])
quant=obj({'type':{'const':'quantitative'},'quantity':ident,'result':obj({'state':e('observed','not_observed','censored'),
            'value':num(),'unit':ident,'uncertainty':uncertainty,'censoring':s()},['state'],**{'allOf':[
               {'if':{'properties':{'state':{'const':'observed'}}},'then':{'required':['value','unit','uncertainty']}},
               {'if':{'properties':{'state':{'const':'not_observed'}}},'then':{'not':{'required':['value']}}},
               {'if':{'properties':{'state':{'const':'censored'}}},'then':{'required':['censoring','unit']}}]}
            ),'estimand':s(),'parameter':ident,'model':ident},['type','quantity','result'])
step=obj({'step_id':s(),'action':s(),'participants':arr(obj({'role':s(),'entity':ident},['role','entity'])),'conditions':arr(s())},['step_id','action'])
transition=obj({'from':s(),'to':s(),'relation':s(),'condition':s()},['from','to','relation'])
process=obj({'type':{'const':'process'},'process_name':s(),'steps':arr(step,1),'transitions':arr(transition),
             'participants':arr(obj({'role':s(),'entity':ident},['role','entity']))},['type','process_name','steps','transitions'])
conjecture=obj({'type':{'const':'conjecture'},'hypothesis':{'oneOf':[rel,quant,process]},'rationale':s(),
                'predictions':arr(obj({'statement':s(),'observation_type':s()},['statement']))},['type','hypothesis','rationale'])

context=obj({'field':ident,'state':e('reported','not_reported','unknown','not_applicable','withheld'),
             'value':{'not':{'type':'null'}},'attribution':source},['field','state'])
context['allOf']=[{'if':{'properties':{'state':{'const':'reported'}}},'then':{'required':['value']}},
                  {'if':{'properties':{'state':{'enum':['not_reported','unknown','not_applicable','withheld']}}},
                   'then':{'not':{'required':['value']}}}]

evidence = obj({'evidence_id':s(),'source':source,
                'basis':e('direct_observation','experimental_measurement','curated_assessment','computational_inference','simulation','formal_derivation','other'),
                'direction':e('supports','contradicts','qualifies','inconclusive','contextual'),
                'outcome':e('positive','negative','measured_zero','null_result','inconclusive','failed','unreported','unavailable','not_derivable'),
                'independence':e('unknown','confirmed_shared','probable_overlap','assessed_independent'),
                'related_evidence_ids':arr(s()),'method':s(),'modality':s(),'notes':s()},
               ['evidence_id','source','basis','direction','outcome','independence'])
activity=obj({'activity_id':s(),'kind':s(),'agent':ident,'input_entities':arr(ident),'output_entities':arr(ident),
              'protocol':source,'software':source},['activity_id','kind','agent'])
provenance=obj({'original_issuer':ident,
                'origin':source,
                'activities':arr(activity),
                'distribution':arr(obj({'distributor':ident,'distribution_record':source,'origin_assertion_ref':s()},['distributor','distribution_record']))},
               ['original_issuer','origin','activities','distribution'])
derivation=obj({'kind':e('primary','source_transcription','analysis','composition'),
                'components':arr(parref),'rule':s(),'activity_id':s(),'inherited_evidence':{'const':False}},['kind'])
derivation['allOf']=[{'if':{'properties':{'kind':{'const':'composition'}}},
                      'then':{'required':['components','rule','inherited_evidence'],
                              'properties':{'components':arr(parref,1)}}},
                     {'if':{'properties':{'kind':{'enum':['primary','source_transcription','analysis']}}},
                      'then':{'not':{'required':['inherited_evidence']}}}]

schema={
 '$schema':'https://json-schema.org/draft/2020-12/schema',
 '$id':'https://example.org/par/candidate/0.2.0/par-core.schema.json',
 'title':'PAR Core 0.2.0 candidate. Provisional, not accepted or released.',
 'description':'Scientific representation prototype, with distinct structural and semantic validators.',
 'type':'object',
 'properties':{
  'schema_version':{'const':'0.2.0-candidate'},
  'par_id':s(),'par_version':s(),
  'record_status':e('draft','release_candidate','released','withdrawn'),
  'record_identity':obj({'origin_assertion_identifier':ident,'revision_kind':e('initial','representation_correction','evidence_update','scientific_revision'),
                          'predecessors':arr(parref),'successors':arr(parref)},['revision_kind','predecessors']),
  'proposition':{'oneOf':[rel,quant,process,conjecture]},
  'interpretation':obj({'polarity':e('affirmative','negative','unspecified'),
                        'epistemic_status':e('asserted','observed','hypothesized','disputed','refuted','undetermined'),
                        'conflict_status':e('none_known','reported_conflict','unassessed')},['polarity','epistemic_status','conflict_status']),
  'scope':obj({'observed_system':ident,'claimed_system':ident,'unit_of_observation':s(),
               'aggregation_level':e('single','sample','cohort','population','model','other'),
               'projection':obj({'kind':e('none','inference','extrapolation','transport'),
                                 'basis':s(),'inputs':arr(parref)},['kind']),
               'context':arr(context)},['observed_system','claimed_system','unit_of_observation','aggregation_level','projection','context']),
  'evidence':arr(evidence),
  'provenance':provenance,
  'derivation':derivation,
  'verification':obj({'status':e('unverified','source_checked','independently_checked','failed','not_applicable'),
                      'reviewers':arr(ident),'notes':s()},['status','reviewers']),
  'rights':obj({'access':e('open','restricted','unknown'),'statement':s(),'source':source},['access','statement','source']),
  'profiles':arr(obj({'identifier':ident,'version':s()},['identifier','version']))
 },
 'required':['schema_version','par_id','par_version','record_status','record_identity','proposition','interpretation','scope','evidence','provenance','derivation','verification','rights','profiles'],
 'additionalProperties':False,
 '$defs':{'identifier':ident,'par_reference':parref,'source_locator':source,'uncertainty':uncertainty,'context':context,'evidence':evidence},
}

# Release overlay requires traceable, separately identified evidence; receipt and authorization
# are external policy checks, not automatically implied by structural conformance.
release={
 '$schema':'https://json-schema.org/draft/2020-12/schema',
 '$id':'https://example.org/par/candidate/0.2.0/par-release.schema.json',
 'title':'Candidate PAR release-eligibility structural gate',
 'allOf':[{'$ref':'par-core.schema.json'}, {'properties':{'record_status':{'const':'released'},'evidence':{'type':'array','minItems':1}},
                                            'required':['record_status','evidence']}]
}
for name, data in [('par-core.schema.json',schema),('par-release.schema.json',release)]:
    (ROOT/'schemas'/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print('Wrote core and release schemas; definitions',len(schema['$defs']))
