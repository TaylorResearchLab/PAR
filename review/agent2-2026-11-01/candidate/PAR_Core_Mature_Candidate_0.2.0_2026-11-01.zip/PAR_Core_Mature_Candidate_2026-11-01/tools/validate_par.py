#!/usr/bin/env python3
"""Candidate PAR semantic checks complement JSON Schema Draft 2020-12.

These checks constrain internal consistency only. They do not verify a source,
scientific validity, rights or authorization.
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker, RefResolver

ROOT=Path(__file__).resolve().parents[1]
CORE=json.loads((ROOT/'schemas/par-core.schema.json').read_text())
RELEASE=json.loads((ROOT/'schemas/par-release.schema.json').read_text())

def _id(x): return (x['scheme'],x['value'])
def structural_errors(record:dict,release:bool=False):
    # Resolver is used to restrict the only external $ref to a local schema.
    if release:
        v=Draft202012Validator(RELEASE,format_checker=FormatChecker(),resolver=RefResolver.from_schema(RELEASE,store={'par-core.schema.json':CORE}))
    else: v=Draft202012Validator(CORE,format_checker=FormatChecker())
    return sorted([f'{"/".join(map(str,x.absolute_path)) or "root"}: {x.message}' for x in v.iter_errors(record)])

def semantic_errors(record:dict):
    """Run only on a structurally valid record."""
    errors=[]
    scope=record['scope']
    different=_id(scope['observed_system'])!=_id(scope['claimed_system'])
    projection=scope['projection']
    if different and projection['kind']=='none':
        errors.append('projection: observed and claimed systems differ but projection.kind=none')
    if projection['kind']!='none' and not projection.get('basis'):
        errors.append('projection: nontrivial projection requires a basis')
    if not different and projection['kind']=='none' and projection.get('basis'):
        # A basis is unnecessary but preserving it is harmless. No failure.
        pass
    c=record['record_identity']
    if c['revision_kind']=='initial' and c['predecessors']:
        errors.append('identity: initial revision has predecessors')
    if c['revision_kind']!='initial' and not c['predecessors']:
        errors.append('identity: noninitial revision requires predecessor')
    for pred in c['predecessors']:
        if pred['par_id']==record['par_id'] and pred['par_version']==record['par_version']:
            errors.append('identity: record references its own version as predecessor')

    deriv=record['derivation']
    if deriv['kind']=='composition':
        for part in deriv['components']:
            if part['par_id']==record['par_id'] and part['par_version']==record['par_version']:
                errors.append('derivation: composition includes current record as input')

    ev=record['evidence']; ids=[x['evidence_id'] for x in ev]
    if len(ids)!=len(set(ids)):
        errors.append('evidence: duplicate evidence_id within record')
    # Evidence direction is the scientific relation between the evidence and
    # proposition. An adverse or negative observation can *support* a negative claim.
    # No inference between these axes is permitted here.

    def check_prop(p):
        if p['type']=='conjecture':
            check_prop(p['hypothesis'])
        if p['type']=='quantitative':
            r=p['result']
            if r['state']=='observed':
                u=r['uncertainty']; k=u['kind']
                if k in ('standard_error','standard_deviation') and u['value']<0:
                    errors.append('quantitative: uncertainty spread must be nonnegative')
                if k in ('confidence_interval','credible_interval') and u['lower']>u['upper']:
                    errors.append('quantitative: interval lower bound exceeds upper bound')
        if p['type']=='process':
            steps=p['steps']; labels=[x['step_id'] for x in steps]
            if len(set(labels))!=len(labels): errors.append('process: duplicate step_id')
            for t in p['transitions']:
                if t['from'] not in labels or t['to'] not in labels:
                    errors.append('process: transition references absent step')
    check_prop(record['proposition'])
    return sorted(set(errors))

def validate(record,release=False):
    errs=structural_errors(record,release)
    if not errs: errs.extend(semantic_errors(record))
    return errs

def main():
    p=argparse.ArgumentParser();p.add_argument('file');p.add_argument('--release',action='store_true');a=p.parse_args()
    rec=json.loads(Path(a.file).read_text());errs=validate(rec,a.release)
    print(json.dumps({'file':a.file,'gate':'release' if a.release else 'core','passed':not errs,'errors':errs},indent=2))
    return int(bool(errs))
if __name__=='__main__': sys.exit(main())
