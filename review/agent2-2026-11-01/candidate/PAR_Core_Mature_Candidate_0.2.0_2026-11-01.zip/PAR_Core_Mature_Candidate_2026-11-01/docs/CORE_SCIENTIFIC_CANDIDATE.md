# Portable Assertion Records, Core scientific candidate 0.2.0

**State:** Agent 1 construction candidate, 1 November 2026. No Agent 2 review or User acceptance. This document proposes testable definitions. It does not supersede the public GitHub v0.01 scaffold or the accepted Notion decisions.

**Authoring instance:** `PAR-GPT-20261031-02`. **Base GitHub repository commit inspected:** `d658a7117489faa746dc91fcacf15c4e6dea82ee`.

## Scientific object

A Portable Assertion Record (PAR) identifies a bounded scientific proposition together with the context that determines its interpretation, the evidence attributed to it, the origins of the assertion, its transformation history, and its version state. Scientific propositions and evidence records remain separate objects. Each evidence item records what was observed or derived, where it originated, and whether it supports, contradicts, qualifies or otherwise relates to the proposition. Provenance distinguishes the originating issuer from a translator and subsequent distributors.

A Portable Assertion Database (PAD) is a versioned collection of identified PAR versions with a manifest, source release references, access conditions and validation reports. Storage in a graph is a representation choice. A PAD can support graph assembly without requiring graph extraction to recover the source assertions.

This candidate separates five identities: (1) a scientific proposition or proposition meaning, (2) an originating assessment or observation, (3) the portable record identifier, (4) a record version, and (5) an encoded representation or PAD membership. The schema currently defines `par_id`, `par_version` and an optional origin assertion identifier. An accepted policy for cross-producer ID reconciliation, split/merge identity and scientific revision is still required. Identifier text does not establish equality of scientific meaning.

## Candidate typed propositions

`relational` represents an oriented predicate between identified referents. Referent identity consists of an identifier scheme and literal value; an IRI or CURIE is one permitted scheme rather than a universal requirement. `quantitative` records a quantity and a result state, with units and explicit uncertainty for observed values. The result states distinguish measured zero, absence of a reported measurement and censoring. `process` represents named steps and connections among them. `conjecture` wraps a relational, quantitative or process hypothesis with a rationale and optional testable predictions. The nested form is **provisional**. Agent 2 should challenge whether conjecture belongs wholly to epistemic status rather than proposition type.

A conjecture can contain an experimentally tested component without making the conjecture itself established. The `interpretation.epistemic_status` field independently records whether the claim is asserted, observed, hypothesized, disputed, refuted or undetermined. Domain profiles can refine this distinction. The Systems Annotation profile must continue to distinguish `SYSEV`, `SYSAST`, `SYSPROC` and `SYSCONJ`.

A compound or traversed conclusion can be represented by a new proposition with `derivation.kind=composition`. It must name its input PAR IDs and versions, describe the derivation rule and set `inherited_evidence=false`. Traceable evidence for the new conclusion is represented by evidence items linked to its own derivation or validation activity. Component identifiers alone establish lineage and do not imply scientific support for the derived proposition.

## Quantities and unsuccessful observation

An `observed` quantitative result includes a numeric value, unit identity and an uncertainty description. The permitted uncertainty classes include standard error, standard deviation, confidence interval, credible interval, named distribution, exact value and not reported. This captures uncertainty **representation**, not the correctness of its statistical method. Model context, parameter identity and estimand may be supplied. Observations of the value zero retain numeric `0`, while `not_observed` omits a numeric value. Null experimental results and failed observations are recorded at the evidence level with distinct outcomes. A recorded failure may itself support an assertion about procedure performance; it must not silently become a negative result for a different biological or physical claim.

Evidence outcomes include `positive`, `negative`, `measured_zero`, `null_result`, `inconclusive`, `failed`, `unreported`, `unavailable` and `not_derivable`. The last category is included provisionally to test preservation of an unsuccessful analysis. Agent 2 should assess whether a `not_derivable` analysis result belongs in a linked audit record rather than in an evidence object. The source's original language and event distinction should be retained by a domain profile.

Evidence direction and observed outcome are independent. For example, an experimental absence can **support** a negative proposition while contradicting an affirmative proposition. Neither the label `negative` nor `null_result` determines evidence direction without a specified claim.

Context has explicit states `reported`, `not_reported`, `unknown`, `not_applicable`, and `withheld`. A reported empty collection is distinct from missingness. A context value is absent when a missingness state is selected. The current candidate rejects a literal JSON null for `reported` context to avoid loss of scientific meaning; a future profile may introduce an explicit null-valued measurement representation.

## Scope and interpretation

Every record describes the observed system and claimed system, the unit of observation and the level of aggregation. If the systems differ, the claim requires an explicit projection kind and basis. The validator checks the presence of a basis and does not assess whether the biological or physical inference is warranted. A pharmacovigilance population estimate cannot be substituted for a case observation solely because its subject and predicate labels match. The projected and observed systems remain distinguishable after graph or table serialization.

## Evidence, origin and distribution

A released PAR includes one or more separately identified evidence items. Each item contains a source or originating activity identifier and a usable locator. This requirement concerns source traceability. Supporting, contradicting and inconclusive evidence may all be included. Traceability, scientific verification, acceptance and distribution authorization are distinct processes. An evidenced proposition can remain disputed.

The `provenance.original_issuer` identifies who made the source claim. The `provenance.origin` references a primary source record or activity. `provenance.activities` identifies subsequent construction activities. `provenance.distribution` records redistributors separately. A source document can contain multiple independent assessments. Conversely, identical source assessments disseminated by two distributors remain one original assertion. Independent evidence cannot be deduced from distinct URL or DOI strings alone. The current schema records distribution but does not yet implement cross-PAD reconciliation.

A `record_status=draft` may have an empty evidence array. `released` records must satisfy the supplemental release evidence schema. The actual scientific release decision also requires rights and external approval. These checks remain distinct even when a record is structurally valid.

## Identity and revision

`par_id` is intended to remain stable across revisions that preserve the identity of an originating assertion. `par_version` denotes a particular record state. The candidate records predecessors and revision kinds such as `representation_correction`, `evidence_update` and `scientific_revision` but does not settle when a change becomes a new originating assertion. Source assessments produced at different times or by different assessors can share evidence without sharing assertion identity. Provisional identifiers in synthetic fixtures have no external registration.

The eventual policy must resolve alternative producers minting different PAR IDs for the same assessment, as well as a source that splits one assertion into two or merges prior assertions. Version changes and scientific identity changes are distinct. Reconciliation must preserve the historical identities and a reason for every merge or split.

## Profiles and transport

PAR Core carries no required biomedical entity, ontology, clinical phenotype or assay vocabulary. Profiles supply domain constraints and source-specific fidelity criteria. In particular DevMap-CHD distinguishes variant, gene and disease phenotype association resolutions, while Systems Annotation preserves its evidence, assertion, process and conjecture layers.

JKG is a potential transport and graph assembly representation of PARs. Its relationship structures, source attribution and basic concept node types can express many relational PARs. A full adapter must specify how quantitative values, process steps, evidence directions, observation scope, PAR identity, original issuer and record versions are preserved in JKG. The existing `par-converters` DisMech implementation translates into a bounded JKG document and does not establish conformance to this candidate.

For every adapter, exact semantic fields must survive a round trip or the conversion must report a documented loss. JSON equality after JSON serialization is an initial smoke test only. No JKG, RDF, SQL or property graph round trip was executed in this candidate construction.

## Validation classes

1. **Structural conformance:** Draft 2020-12 JSON Schema shape, required fields and typed proposition form.
2. **Internal semantic conformance:** scoped system projection, evidence IDs, process endpoints, uncertainty bounds, revision lineage and composition rules. The accompanying Python validator performs a selected subset.
3. **Source fidelity:** alignment of proposition, uncertainty, provenance, evidence direction and scope with original records or primary activities. Requires source-backed checking.
4. **Scientific review:** independent assessment of meaning, inference basis and evidence sufficiency.
5. **Distribution eligibility:** rights, permitted releases, authorization and PAD manifest checks.

Each class receives an independent result. A passing result in an earlier class cannot substitute for a later check.

## Accepted decisions preserved, and explicit open decisions

**Accepted:** discipline-independent Core; profiles separate from Core; evidence required for released PARs; evidence-free drafts permitted; SYSEV/SYSAST/SYSPROC/SYSCONJ distinctions; distinct null, negative, contradictory and missing observations; original issuer separated from distributors; derived claims do not inherit evidence standing; independent Claude challenge and User acceptance before promotion.

**Open:** proposition and assertion identity across sources; when scientific revisions require new identity; conjecture ontology; required uncertainty representations for censored results; formal evidence independence; exact context null semantics; scope projection validation beyond structural presence; valid evidence on a derived assertion; cross-format preservation; PAD release policy and rights; scientific source fidelity; prior-art search coverage.
