# Source-aware comparison against PAR GitHub v0.01

Source inspected: `TaylorResearchLab/PAR`, GitHub `main` commit `d658a7117489faa746dc91fcacf15c4e6dea82ee`, including `SPECIFICATION.md`, schema `schemas/par-core-0.01.schema.json`, test module `tests/test_draft_profile.py` and fictional fixture. The public version is explicitly provisional under the User's October 31 accepted decision.

| Subject | GitHub v0.01, directly checked | Candidate 0.2.0 design | Scientific consequence or migration work |
| --- | --- | --- | --- |
| Core claim | Required `claim.graph.relationships` and `claim.connection_points`; a relationship is compulsory | `proposition` has relational, quantitative, process or conjecture shapes | Adapter maps older relation graphs into typed propositions, does not force unrelated physical measurements into triples |
| Referent identifiers | Predicate and connection IRIs required | `scheme` and `value`, with domain-specific schemes allowed | JKG/RDF adapters may mint IRI-compatible serialization identifiers while preserving original scheme and value |
| Origin | Publication or DOI-identified dataset required | Primary instrument, activity, dataset, publication, analysis and formal derivation source locators | Reconcile source-native provenance with persistent location and original issuer distinctions |
| Evidence | Availability and items; no core `record_status` validation | Evidence items individually traceable; draft/release overlay | Accept drafts with no evidence, reject a released assertion without traceable evidence |
| Quantitation | Graph/categorical context model | Explicit quantity, observed value, units, uncertainty, estimand and model/parameter | Preserves numerical scientific content rather than storing it as untyped edge annotation |
| Process and conjecture | Graph relationship composition | Process steps/transitions and nested conjecture hypothesis | Challenge nested conjecture design with Agent 2 before normativizing |
| Evidence polarity/outcome | `role` includes `supports` and `contradicts`; availability separately encoded | Outcome, direction, interpretation polarity and record epistemic state separate | Maintains measured zero, negative evidence and null results as different concepts |
| Source genealogy | `origin`, distribution and genealogy fields | Original issuer, origin and distribution entities, evidence independence classifications | Reconciliation procedure across independent sources remains to be implemented |
| Observed vs claimed system | Context array | Explicit observation/claim scope with projection basis | Prevents scope expansion without a documented inferential step |
| Composition | Compound graph and composition rationale | Derivation with explicit component PAR versions, rule and `inherited_evidence=false` | Input PARs do not transfer direct evidentiary status to new claim |
| Conformance | Structural schema/test fixture; source fidelity deferred | Structural schema, internal consistency checks and explicit later review classes | Tests still required for source fidelity, JKG/RDF/SQL round trip, rights and authorization |

The October 31 candidate archives report 15/15 and 9/9 synthetic outcomes, but the archives were absent from this session's accessible Project files. This implementation is reconstructed from accepted scientific requirements and Notion descriptions rather than a patch to the inaccessible archives.
