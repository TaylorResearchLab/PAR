# Open, failed, negative and not-derivable findings

Status: 1 November 2026, Agent 1 candidate. This inventory preserves all observed or unverified outcomes for User disposition.

1. **Unavailable prior implementation archives:** neither October 31 ZIP bundle is present in the accessible project container. Previously reported SHA-256 digests and synthetic test totals are from Notion, not independently replicated. Comparison against their actual code is incomplete.
2. **Source truth unverified:** examples are fictional. No actual scientific source record, physical instrument output or biology source document was audited. Source-fidelity conformance is untested.
3. **JSON-only semantics:** no JKG, RDF, SHACL, SQL or property graph conformance/round trip was tested. A JSON dump/load smoke test cannot demonstrate a transport-independent contract.
4. **Release authorization external:** the structural release gate accepts a record whose rights state is `unknown` and whose source verification is `unverified`, provided it has one located evidence item. This preserves separation of evidence traceability and authorized release. The release authorization policy must enforce rights and User acceptance outside the structural gate.
5. **Contradictory-only release possible:** the structural overlay admits a traceable contradictory-only evidence set. Such a record remains disputed; release policy should distinguish distribution as a reported disputed claim from endorsement.
6. **No independent evidence detector:** records can list several distributors of one source assertion, but this candidate does not infer shared original identity or independence among evidence items across PARs.
7. **Not-derivable analysis:** synthetic case represents `not_derivable` as an evidence outcome linked to an analysis artifact. Agent 2 must decide whether it belongs in an explicit failed-derivation audit record without a proposition.
8. **Conjecture representation unresolved:** the schema uses a `conjecture` form wrapping relational, quantitative or process hypotheses. Alternative design may express conjecture only through interpretation, preserving Systems Annotation's `SYSCONJ` profile distinction.
9. **Scope inference unassessed:** validator checks a nonempty projection basis, not its adequacy. An unrelated text basis can pass.
10. **Statistical semantics unassessed:** validator tests interval order and nonnegative uncertainty scale. It does not check distributions, sampling, confidence interval methods, units and population estimands against sources.
11. **Version identity unresolved:** the candidate enforces predecessor presence for revisions but does not prove two versions describe the same originating scientific assertion or define split/merge identity policy.
12. **Missing source values in current converter:** the `par-converters` DisMech path omits `None`, empty collection and empty string values. Their source distinctions cannot be reconstructed from the translated JKG alone. A source-aware audit is needed before declaring the converter lossless for PAR content.
13. **Formal prior art pending:** the independent PAR Prior-Art Search Log shows no formal PAR coverage declaration from the User, and the Citation Validation Ledger has no primary text evidence validation for the framework novelty claims.
14. **Agent 2 review pending:** Claude previously reviewed the high-level three-layer architecture on October 24 but has not reviewed this 0.2.0 candidate code. User has not accepted this version.

Every item remains open until the User records its disposition through the independent PAR process.
