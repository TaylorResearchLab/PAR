# Claude Agent 2 independent challenge instructions

Review pin: Candidate `0.2.0-candidate`, Agent 1 `PAR-GPT-20261031-02`, build of 1 November 2026. Read the archive SHA-256 in `reports/manifest_sha256.txt` and verify all individual files before testing. The base public PAR repository was observed at commit `d658a7117489faa746dc91fcacf15c4e6dea82ee`.

Agent 1 previously read Claude's 24 October architectural review; this candidate is informed by that exposure. Claude has **not** reviewed this implementation. Perform an independent source and code assessment and record any exposure to this Agent 1 document. Report positive, negative, null, contradictory, failed, unverified and not-derivable outcomes separately.

Scientific challenges:

1. Identify any continuing discipline-specific assumptions in Core fields, identifier requirements, unit choices or evidence categories. Challenge with a real physical measurement and a non-biomedical process model.
2. Decide whether a conjecture is its own proposition form or an epistemic qualifier on any proposition. Preserve `SYSCONJ` distinction in Systems Annotation either way.
3. Challenge the boundaries between a scientific proposition, originating assessment, portable record, record version, representation checksum and redistributor.
4. Test whether a negative observation can support a negative proposition without being mislabeled contradictory. Test a null result and an aborted experiment separately.
5. Challenge the release overlay's admission of a traceable but wholly contradictory or inconclusive evidence set. Propose a scientifically coherent policy separating traceability from endorsement.
6. Provide counterexamples for measured system versus claimed system, individual versus population and evidence independence.
7. Test a new composition that cites previously supported inputs but does not gain their evidence as its own. Evaluate derivation-produced evidence separately.
8. Identify information loss during conversion to the current JKG model and DisMech converter, including empty vs missing source values.
9. Test the code as supplied and audit test assertions for cases that pass for the wrong reason. Verify versioned file digests and report which exact test command ran.
10. Recommend a precise definition for scientific identity changes and subsequent version supersession. Preserve an unmerged state when independent source records are ambiguous.

Do not mark candidate accepted. Provide line/field-level corrections, counterexample records, and test cases. Place independent review results in the PAR Collaboration Log. Submit substantive scientific decisions to the User for acceptance.
